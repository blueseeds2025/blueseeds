import TimetableClient from './TimetableClient';

export default function TimetablePage() {
  return <TimetableClient />;
}
