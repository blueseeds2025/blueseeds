import { StudentsClient } from './StudentsClient';

export const metadata = {
  title: '학생 관리 | 리드앤톡',
};

export default function StudentsPage() {
  return <StudentsClient />;
}
