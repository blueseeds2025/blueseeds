import MakeupManagePage from './MakeupManagePage';

export default function Page() {
  return <MakeupManagePage />;
}