'use client';

import { useState, useEffect } from 'react';
import { 
  X, 
  Plus, 
  Edit2, 
  UserMinus, 
  UserPlus,
  Trash2,
  School,
  Phone,
  FileText,
  ArrowRight,
  Check,
  Loader2,
  MapPin,
  User,
  History,
  ArrowRightLeft,
} from 'lucide-react';

import type { StudentWithDetails, ClassInfo } from '../types';
import { gradeToText } from '../types';
import { styles } from '../constants';
import { getStudentEnrollmentHistory, type EnrollmentHistoryItem } from '../actions/student.actions';

type Props = {
  student: StudentWithDetails;
  availableClasses: ClassInfo[];
  onClose: () => void;
  onEdit: () => void;
  onArchive: () => void;
  onRestore: () => void;
  onDelete: () => void;
  onEnrollToClass: (classId: string) => Promise<boolean>;
  onUnenrollFromClass: (classId: string) => Promise<boolean>;
  onMoveToClass: (fromClassId: string, toClassId: string) => Promise<boolean>;
};

type TabType = 'info' | 'history';

export function StudentDetailPanel({
  student,
  availableClasses,
  onClose,
  onEdit,
  onArchive,
  onRestore,
  onDelete,
  onEnrollToClass,
  onUnenrollFromClass,
  onMoveToClass,
}: Props) {
  const [activeTab, setActiveTab] = useState<TabType>('info');
  const [showAddClass, setShowAddClass] = useState(false);
  const [moveFromClassId, setMoveFromClassId] = useState<string | null>(null);
  
  // 로딩 및 성공 상태
  const [enrollingClassId, setEnrollingClassId] = useState<string | null>(null);
  const [enrolledClassId, setEnrolledClassId] = useState<string | null>(null);
  const [unenrollingClassId, setUnenrollingClassId] = useState<string | null>(null);

  // 이력 데이터
  const [historyItems, setHistoryItems] = useState<EnrollmentHistoryItem[]>([]);
  const [historyLoading, setHistoryLoading] = useState(false);

  // 현재 등록된 반 ID 목록
  const enrolledClassIds = new Set(
    student.enrollments.filter(e => e.is_active).map(e => e.class_id)
  );

  // 등록 가능한 반 (현재 미등록)
  const unenrolledClasses = availableClasses.filter(c => !enrolledClassIds.has(c.id));

  // 이력 탭 선택 시 데이터 로드
  useEffect(() => {
    if (activeTab === 'history' && historyItems.length === 0) {
      loadHistory();
    }
  }, [activeTab]);

  async function loadHistory() {
    setHistoryLoading(true);
    const result = await getStudentEnrollmentHistory(student.id);
    if (result.ok && result.data) {
      setHistoryItems(result.data);
    }
    setHistoryLoading(false);
  }

  // 반 등록 핸들러 (로딩 + 성공 애니메이션)
  const handleEnrollToClass = async (classId: string) => {
    setEnrollingClassId(classId);
    const success = await onEnrollToClass(classId);
    setEnrollingClassId(null);
    
    if (success) {
      setEnrolledClassId(classId);
      setTimeout(() => {
        setEnrolledClassId(null);
        setShowAddClass(false);
      }, 800);
    }
  };

  // 반 제거 핸들러
  const handleUnenrollFromClass = async (classId: string) => {
    setUnenrollingClassId(classId);
    await onUnenrollFromClass(classId);
    setUnenrollingClassId(null);
  };

  return (
    <div className="bg-white rounded-lg border border-[#E8E5E0] h-full flex flex-col">
      {/* 헤더 */}
      <div className="p-4 border-b border-[#E8E5E0]">
        <div className="flex items-center justify-between mb-3">
          <div className="flex items-center gap-2">
            <h2 className="font-semibold text-lg text-[#37352F]">{student.name}</h2>
            <span className={student.is_active ? styles.badge.active : styles.badge.inactive}>
              {student.is_active ? '재원' : '퇴원'}
            </span>
          </div>
          <button
            className="p-1 rounded hover:bg-gray-100 transition-colors"
            onClick={onClose}
          >
            <X className="w-5 h-5 text-gray-400" />
          </button>
        </div>
        
        {/* 탭 */}
        <div className="flex gap-1 bg-gray-100 rounded-lg p-1">
          <button
            className={`flex-1 flex items-center justify-center gap-1.5 px-3 py-1.5 rounded-md text-sm font-medium transition-colors ${
              activeTab === 'info'
                ? 'bg-white text-[#37352F] shadow-sm'
                : 'text-gray-500 hover:text-gray-700'
            }`}
            onClick={() => setActiveTab('info')}
          >
            <User className="w-4 h-4" />
            기본 정보
          </button>
          <button
            className={`flex-1 flex items-center justify-center gap-1.5 px-3 py-1.5 rounded-md text-sm font-medium transition-colors ${
              activeTab === 'history'
                ? 'bg-white text-[#37352F] shadow-sm'
                : 'text-gray-500 hover:text-gray-700'
            }`}
            onClick={() => setActiveTab('history')}
          >
            <History className="w-4 h-4" />
            반 이력
          </button>
        </div>
      </div>

      {/* 컨텐츠 */}
      <div className="flex-1 overflow-y-auto p-4 space-y-6">
        {activeTab === 'info' ? (
          <>
            {/* 기본 정보 탭 */}
        <section>
          <h3 className="text-sm font-medium text-[#37352F] mb-3">기본 정보</h3>
          <div className="space-y-2">
            {/* 학교/학년 */}
            <div className="flex items-center gap-3 text-sm">
              <School className="w-4 h-4 text-gray-400" />
              <span className="text-gray-600">
                {student.school || '-'} / {gradeToText(student.grade)}
              </span>
            </div>
            {/* 보호자 연락처 */}
            <div className="flex items-center gap-3 text-sm">
              <Phone className="w-4 h-4 text-gray-400" />
              <div>
                <span className="text-gray-400 text-xs mr-2">보호자</span>
                {(student.parent_phone || student.phone) ? (
                  <a href={`tel:${student.parent_phone || student.phone}`} className="text-[#6366F1] hover:underline">
                    {student.parent_phone || student.phone}
                  </a>
                ) : (
                  <span className="text-gray-400">-</span>
                )}
              </div>
            </div>
            {/* 학생 연락처 */}
            <div className="flex items-center gap-3 text-sm">
              <User className="w-4 h-4 text-gray-400" />
              <div>
                <span className="text-gray-400 text-xs mr-2">학생</span>
                {student.student_phone ? (
                  <a href={`tel:${student.student_phone}`} className="text-[#6366F1] hover:underline">
                    {student.student_phone}
                  </a>
                ) : (
                  <span className="text-gray-400">-</span>
                )}
              </div>
            </div>
            {/* 주소 */}
            {student.address && (
              <div className="flex items-center gap-3 text-sm">
                <MapPin className="w-4 h-4 text-gray-400" />
                <span className="text-gray-600">{student.address}</span>
              </div>
            )}
          </div>
        </section>

        {/* 학생 특이사항 */}
        {student.memo && (
          <section>
            <h3 className="text-sm font-medium text-[#37352F] mb-2">학생 특이사항</h3>
            <div className="p-3 bg-amber-50 border border-amber-200 rounded-lg">
              <p className="text-sm text-amber-800 whitespace-pre-wrap">{student.memo}</p>
            </div>
          </section>
        )}

        {/* 수강 반 */}
        <section>
          <div className="flex items-center justify-between mb-3">
            <h3 className="text-sm font-medium text-[#37352F]">
              수강 반 ({student.currentClassCount})
            </h3>
          </div>

          {/* 반 추가 버튼 */}
          {!showAddClass ? (
            <button
              className="w-full mb-3 py-2 px-3 border-2 border-dashed border-[#E8E5E0] rounded-lg text-[#9B9A97] hover:border-[#6366F1] hover:text-[#6366F1] transition-colors flex items-center justify-center gap-2"
              onClick={() => setShowAddClass(true)}
            >
              <Plus className="w-4 h-4" />
              반 추가
            </button>
          ) : (
            /* 반 추가 폼 */
            <div className="mb-3 p-3 bg-gray-50 rounded-lg">
              <div className="flex items-center justify-between mb-2">
                <span className="font-medium text-sm">반 선택</span>
                <button
                  className="text-gray-400 hover:text-gray-600"
                  onClick={() => setShowAddClass(false)}
                >
                  <X className="w-4 h-4" />
                </button>
              </div>
              <p className="text-xs text-gray-400 mb-2">클릭하면 바로 등록됩니다</p>
              
              {unenrolledClasses.length === 0 ? (
                <p className="text-sm text-gray-400 text-center py-2">
                  등록 가능한 반이 없습니다
                </p>
              ) : (
                <div className="space-y-1 max-h-40 overflow-y-auto">
                  {unenrolledClasses.map((cls) => {
                    const isEnrolling = enrollingClassId === cls.id;
                    const isEnrolled = enrolledClassId === cls.id;
                    
                    return (
                      <button
                        key={cls.id}
                        className={`
                          w-full flex items-center justify-between p-2 rounded text-left transition-all
                          ${isEnrolled 
                            ? 'bg-green-100 text-green-700' 
                            : 'hover:bg-white'
                          }
                        `}
                        onClick={() => handleEnrollToClass(cls.id)}
                        disabled={isEnrolling || isEnrolled}
                      >
                        <div className="flex items-center gap-2">
                          <div
                            className="w-3 h-3 rounded-full"
                            style={{ backgroundColor: cls.color }}
                          />
                          <span className="text-sm">{cls.name}</span>
                        </div>
                        
                        {isEnrolling && (
                          <Loader2 className="w-4 h-4 animate-spin text-[#6366F1]" />
                        )}
                        {isEnrolled && (
                          <div className="flex items-center gap-1 text-green-600">
                            <Check className="w-4 h-4" />
                            <span className="text-xs">등록됨</span>
                          </div>
                        )}
                      </button>
                    );
                  })}
                </div>
              )}
            </div>
          )}

          {/* 등록된 반 목록 */}
          {student.enrollments.filter(e => e.is_active).length === 0 ? (
            <p className="text-sm text-gray-400 text-center py-4">
              등록된 반이 없습니다
            </p>
          ) : (
            <div className="space-y-2">
              {student.enrollments
                .filter(e => e.is_active)
                .map((enrollment) => {
                  const isUnenrolling = unenrollingClassId === enrollment.class_id;
                  
                  return (
                    <div
                      key={enrollment.id}
                      className={`
                        flex items-center justify-between p-3 rounded-lg transition-all
                        ${isUnenrolling ? 'bg-red-50 opacity-50' : 'bg-gray-50'}
                      `}
                    >
                      <div className="flex items-center gap-2">
                        <div
                          className="w-3 h-3 rounded-full"
                          style={{ backgroundColor: enrollment.class_color }}
                        />
                        <span className="text-sm font-medium text-[#37352F]">
                          {enrollment.class_name}
                        </span>
                      </div>
                      
                      <div className="flex items-center gap-1">
                        {/* 반 이동 */}
                        {moveFromClassId === enrollment.class_id ? (
                          <div className="flex items-center gap-1">
                            <select
                              className="text-xs border border-gray-200 rounded px-2 py-1"
                              onChange={async (e) => {
                                if (e.target.value) {
                                  await onMoveToClass(enrollment.class_id, e.target.value);
                                  setMoveFromClassId(null);
                                }
                              }}
                              defaultValue=""
                            >
                              <option value="" disabled>이동할 반 선택</option>
                              {unenrolledClasses.map((cls) => (
                                <option key={cls.id} value={cls.id}>
                                  {cls.name}
                                </option>
                              ))}
                            </select>
                            <button
                              className="p-1 text-gray-400 hover:text-gray-600"
                              onClick={() => setMoveFromClassId(null)}
                            >
                              <X className="w-3 h-3" />
                            </button>
                          </div>
                        ) : (
                          <>
                            <button
                              className="p-1 text-gray-400 hover:text-blue-500 transition-colors"
                              onClick={() => setMoveFromClassId(enrollment.class_id)}
                              title="반 이동"
                              disabled={isUnenrolling}
                            >
                              <ArrowRight className="w-4 h-4" />
                            </button>
                            <button
                              className="p-1 text-gray-400 hover:text-red-500 transition-colors"
                              onClick={() => handleUnenrollFromClass(enrollment.class_id)}
                              title="반에서 제거"
                              disabled={isUnenrolling}
                            >
                              {isUnenrolling ? (
                                <Loader2 className="w-4 h-4 animate-spin" />
                              ) : (
                                <UserMinus className="w-4 h-4" />
                              )}
                            </button>
                          </>
                        )}
                      </div>
                    </div>
                  );
                })}
            </div>
          )}
        </section>
          </>
        ) : (
          /* 반 이력 탭 */
          <section>
            <h3 className="text-sm font-medium text-[#37352F] mb-4">반 변동 이력</h3>
            
            {historyLoading ? (
              <div className="flex items-center justify-center py-8">
                <Loader2 className="w-6 h-6 animate-spin text-gray-400" />
              </div>
            ) : historyItems.length === 0 ? (
              <div className="text-center py-8 text-gray-400">
                <History className="w-8 h-8 mx-auto mb-2 opacity-50" />
                <p className="text-sm">반 이력이 없습니다</p>
              </div>
            ) : (
              <div className="relative">
                {/* 타임라인 세로선 */}
                <div className="absolute left-[7px] top-2 bottom-2 w-0.5 bg-gray-200" />
                
                <div className="space-y-4">
                  {historyItems.map((item, index) => (
                    <div key={item.id} className="relative flex gap-3">
                      {/* 타임라인 점 */}
                      <div className={`relative z-10 w-4 h-4 rounded-full border-2 mt-0.5 ${
                        item.action === 'enrolled' 
                          ? 'bg-green-100 border-green-500'
                          : 'bg-red-100 border-red-400'
                      }`} />
                      
                      {/* 내용 */}
                      <div className="flex-1 pb-2">
                        <div className="flex items-center gap-2 mb-1">
                          <div
                            className="w-3 h-3 rounded-full"
                            style={{ backgroundColor: item.class_color }}
                          />
                          <span className="font-medium text-sm text-[#37352F]">
                            {item.class_name}
                          </span>
                          <span className={`text-xs px-1.5 py-0.5 rounded ${
                            item.action === 'enrolled'
                              ? 'bg-green-100 text-green-700'
                              : 'bg-red-100 text-red-600'
                          }`}>
                            {item.action === 'enrolled' ? '등록' : '종료'}
                          </span>
                        </div>
                        
                        <div className="text-xs text-gray-500 space-y-0.5">
                          <p>
                            {item.action === 'enrolled' 
                              ? `${item.start_date} 등록`
                              : `${item.end_date} 종료`
                            }
                          </p>
                          {item.created_by_name && (
                            <p className="text-gray-400">
                              변경자: {item.created_by_name}
                            </p>
                          )}
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            )}
          </section>
        )}
      </div>

      {/* 푸터 - 액션 버튼 */}
      <div className="p-4 border-t border-[#E8E5E0]">
        <div className="flex gap-2">
          <button
            className={styles.button.secondary + ' flex-1 flex items-center justify-center gap-1'}
            onClick={onEdit}
          >
            <Edit2 className="w-4 h-4" />
            정보 수정
          </button>
          
          {student.is_active ? (
            <button
              className="flex-1 px-4 py-2 bg-amber-100 text-amber-700 rounded-lg hover:bg-amber-200 transition-colors font-medium flex items-center justify-center gap-1"
              onClick={onArchive}
            >
              <UserMinus className="w-4 h-4" />
              퇴원
            </button>
          ) : (
            <button
              className="flex-1 px-4 py-2 bg-green-100 text-green-700 rounded-lg hover:bg-green-200 transition-colors font-medium flex items-center justify-center gap-1"
              onClick={onRestore}
            >
              <UserPlus className="w-4 h-4" />
              재원
            </button>
          )}
          
          <button
            className="p-2 text-gray-400 hover:text-red-500 hover:bg-red-50 rounded-lg transition-colors"
            onClick={onDelete}
            title="삭제"
          >
            <Trash2 className="w-5 h-5" />
          </button>
        </div>
      </div>
    </div>
  );
}
