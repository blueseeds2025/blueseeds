import { WeeklyReportClient } from './WeeklyReportClient';

export default function AdminReportsPage() {
  return (
    <div className="p-6 max-w-6xl mx-auto">
      <WeeklyReportClient />
    </div>
  );
}
