// ============================================================================
// 기본 항목 설정 섹션 (운영 설정 탭용)
// ============================================================================
'use client';

import { useState, useEffect } from 'react';
import { Switch } from '@/components/ui/switch';
import { BookOpen, FileText, Plus, Trash2, Loader2 } from 'lucide-react';
import { toast } from 'sonner';
import {
  getMaterials,
  createMaterial,
  deleteMaterial,
  type BasicSettings,
  type Material,
} from '../actions/settings.actions';

interface BasicSettingsSectionProps {
  settings: BasicSettings;
  isSaving: boolean;
  onUpdateSetting: (key: keyof BasicSettings, value: boolean) => void;
}

export default function BasicSettingsSection({ 
  settings,
  isSaving,
  onUpdateSetting,
}: BasicSettingsSectionProps) {
  // 교재 관련 상태
  const [materials, setMaterials] = useState<Material[]>([]);
  const [isLoadingMaterials, setIsLoadingMaterials] = useState(false);
  const [isMaterialsExpanded, setIsMaterialsExpanded] = useState(false);
  const [newMaterialName, setNewMaterialName] = useState('');
  const [isAddingMaterial, setIsAddingMaterial] = useState(false);
  const [deletingId, setDeletingId] = useState<string | null>(null);

  // 진도 ON일 때 교재 목록 로드
  useEffect(() => {
    if (settings.progress_enabled) {
      loadMaterials();
    }
  }, [settings.progress_enabled]);

  async function loadMaterials() {
    setIsLoadingMaterials(true);
    const result = await getMaterials();
    if (result.ok) {
      setMaterials(result.data);
    }
    setIsLoadingMaterials(false);
  }

  async function handleAddMaterial() {
    if (!newMaterialName.trim()) return;
    
    setIsAddingMaterial(true);
    const result = await createMaterial(newMaterialName.trim());
    
    if (result.ok) {
      setMaterials([...materials, result.data]);
      setNewMaterialName('');
      toast.success('교재가 추가되었습니다');
    } else {
      toast.error(result.message);
    }
    setIsAddingMaterial(false);
  }

  async function handleDeleteMaterial(id: string, name: string) {
    if (!confirm(`"${name}" 교재를 삭제할까요?`)) return;
    
    setDeletingId(id);
    const result = await deleteMaterial(id);
    
    if (result.ok) {
      setMaterials(materials.filter(m => m.id !== id));
      toast.success('교재가 삭제되었습니다');
    } else {
      toast.error(result.message);
    }
    setDeletingId(null);
  }

  function handleKeyDown(e: React.KeyboardEvent) {
    if (e.key === 'Enter' && !e.nativeEvent.isComposing) {
      e.preventDefault();
      handleAddMaterial();
    }
  }

  return (
    <section className="bg-white rounded-xl border border-stone-200 p-6">
      <div className="mb-4">
        <h2 className="text-lg font-semibold text-stone-800">📝 기본 항목 설정</h2>
        <p className="text-sm text-stone-500 mt-1">
          피드 입력 시 표시할 기본 항목을 선택하세요
        </p>
      </div>
      
      <div className="space-y-3">
        {/* 진도 입력 */}
        <div className="rounded-lg border border-stone-200 overflow-hidden">
          <div className="flex items-center justify-between py-3 px-4 bg-stone-50">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-lg bg-[#6366F1]/10 flex items-center justify-center">
                <BookOpen className="w-5 h-5 text-[#6366F1]" />
              </div>
              <div>
                <div className="font-medium text-stone-800">진도 입력</div>
                <div className="text-sm text-stone-500">학생별 학습 진도 기록</div>
              </div>
            </div>
            <Switch
              checked={settings.progress_enabled}
              onCheckedChange={(v) => onUpdateSetting('progress_enabled', v)}
              disabled={isSaving}
              className="data-[state=checked]:bg-[#6366F1]"
            />
          </div>
          
          {/* 진도 ON일 때 교재 목록 */}
          {settings.progress_enabled && (
            <div className="p-4 border-t border-stone-200 bg-white">
              {/* 헤더 - 클릭하면 펼치기/접기 */}
              <button
                onClick={() => setIsMaterialsExpanded(!isMaterialsExpanded)}
                className="w-full flex items-center justify-between text-left"
              >
                <div className="flex items-center gap-2">
                  <span className="text-sm font-medium text-stone-700">📚 사용 교재</span>
                  <span className="text-xs text-stone-400">({materials.length}개)</span>
                </div>
                <span className="text-xs text-[#6366F1] hover:underline">
                  {isMaterialsExpanded ? '접기 ▲' : '펼치기 ▼'}
                </span>
              </button>
              
              {/* 펼쳐진 상태 */}
              {isMaterialsExpanded && (
                <div className="mt-3">
                  {isLoadingMaterials ? (
                    <div className="flex items-center gap-2 text-sm text-stone-500 py-2">
                      <Loader2 className="w-4 h-4 animate-spin" />
                      불러오는 중...
                    </div>
                  ) : (
                    <div className="space-y-2">
                      {/* 교재 목록 (스크롤 영역) */}
                      <div className="max-h-48 overflow-y-auto space-y-2">
                        {materials.length === 0 ? (
                          <p className="text-sm text-stone-400 py-2">등록된 교재가 없습니다</p>
                        ) : (
                          materials.map((material) => (
                            <div
                              key={material.id}
                              className="flex items-center justify-between py-2 px-3 bg-stone-50 rounded-lg group"
                            >
                              <span className="text-sm text-stone-700">{material.name}</span>
                              <button
                                onClick={() => handleDeleteMaterial(material.id, material.name)}
                                disabled={deletingId === material.id}
                                className="opacity-0 group-hover:opacity-100 p-1 text-stone-400 hover:text-red-500 transition-all disabled:opacity-50"
                              >
                                {deletingId === material.id ? (
                                  <Loader2 className="w-4 h-4 animate-spin" />
                                ) : (
                                  <Trash2 className="w-4 h-4" />
                                )}
                              </button>
                            </div>
                          ))
                        )}
                      </div>
                      
                      {/* 교재 추가 입력 */}
                      <div className="flex items-center gap-2 pt-2 border-t border-stone-100">
                        <input
                          type="text"
                          value={newMaterialName}
                          onChange={(e) => setNewMaterialName(e.target.value)}
                          onKeyDown={handleKeyDown}
                          placeholder="교재명 입력"
                          className="flex-1 px-3 py-2 text-sm border border-stone-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-[#6366F1]/20 focus:border-[#6366F1]"
                          disabled={isAddingMaterial}
                        />
                        <button
                          onClick={handleAddMaterial}
                          disabled={!newMaterialName.trim() || isAddingMaterial}
                          className="flex items-center gap-1 px-3 py-2 text-sm font-medium text-[#6366F1] bg-[#6366F1]/10 rounded-lg hover:bg-[#6366F1]/20 disabled:opacity-50 disabled:cursor-not-allowed transition-colors"
                        >
                          {isAddingMaterial ? (
                            <Loader2 className="w-4 h-4 animate-spin" />
                          ) : (
                            <Plus className="w-4 h-4" />
                          )}
                          추가
                        </button>
                      </div>
                    </div>
                  )}
                </div>
              )}
            </div>
          )}
        </div>

        {/* 시험 점수 */}
        <div className="flex items-center justify-between py-3 px-4 bg-stone-50 rounded-lg">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-lg bg-[#EA580C]/10 flex items-center justify-center">
              <FileText className="w-5 h-5 text-[#EA580C]" />
            </div>
            <div>
              <div className="font-medium text-stone-800">시험 점수</div>
              <div className="text-sm text-stone-500">시험/퀴즈 점수 입력</div>
            </div>
          </div>
          <Switch
            checked={settings.exam_score_enabled}
            onCheckedChange={(v) => onUpdateSetting('exam_score_enabled', v)}
            disabled={isSaving}
            className="data-[state=checked]:bg-[#EA580C]"
          />
        </div>
      </div>
      
      {/* 저장 중 표시 */}
      {isSaving && (
        <div className="mt-3 text-center text-sm text-stone-500">
          저장 중...
        </div>
      )}
    </section>
  );
}
