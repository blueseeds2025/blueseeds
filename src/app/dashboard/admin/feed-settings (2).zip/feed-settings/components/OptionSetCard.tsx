'use client';

import type { CSSProperties } from 'react';
import {
  ChevronDown,
  ChevronRight,
  MoreVertical,
  Pencil,
  Copy,
  Trash2,
  Info,
} from 'lucide-react';

import { DndContext, closestCenter, type DragEndEvent } from '@dnd-kit/core';
import { SortableContext, verticalListSortingStrategy } from '@dnd-kit/sortable';

import { Card, CardContent, CardHeader } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Checkbox } from '@/components/ui/checkbox';
import {
  DropdownMenu,
  DropdownMenuTrigger,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuSeparator,
} from '@/components/ui/dropdown-menu';

import { feedStyles, cn } from '@/styles/feedSettings.styles';
import type { OptionSet, Option, ReportCategory } from '@/types/feed-settings';
import { 
  REPORT_CATEGORIES, 
  REPORT_CATEGORY_LABEL,
  REPORT_CATEGORY_DESCRIPTION,
} from '../feedSettings.constants';

import SortableOptionRow from './SortableOptionRow';

type Props = {
  set: OptionSet;
  expanded: boolean;

  isEditMode: boolean;
  isHighlightAdd?: boolean; // 옵션 추가 입력창 강조 여부

  categoryValue: ReportCategory;
  optionList: Option[];

  // card handlers
  onToggleExpand: () => void;
  onToggleSetActive: () => void;

  // name edit (묶음)
  nameEdit: {
    editing: boolean;
    value: string;
    onStart: () => void;
    onChange: (v: string) => void;
    onConfirm: () => void;
    onCancel: () => void;
  };

  // menu actions
  onDuplicate: () => void;
  onDeleteSet: () => void;

  // category change
  onChangeCategory: (cat: ReportCategory) => void;

  // 주간 리포트 설정
  onToggleWeeklyStats: () => void;

  // confirm dialog (모달용)
  confirm: (options: {
    title: string;
    description: string;
    confirmLabel?: string;
    cancelLabel?: string;
    variant?: 'default' | 'danger';
  }) => Promise<boolean>;

  // dnd
  sensors: any; // dnd-kit sensors 타입 단순화
  onDragEnd: (event: DragEndEvent) => void;

  // option row actions
  onDeleteOption: (optionId: string) => void;
  onUpdateOption: (optionId: string, newLabel: string, newScore: number | null) => void;

  // add option (묶음)
  optionDraft: {
    value: string;
    onChange: (v: string) => void;
    onAdd: () => void;
  };
};

export default function OptionSetCard({
  set,
  expanded,
  isEditMode,
  isHighlightAdd = false,
  categoryValue,
  optionList,

  onToggleExpand,
  onToggleSetActive,

  nameEdit,
  onDuplicate,
  onDeleteSet,

  onChangeCategory,
  onToggleWeeklyStats,

  confirm,

  sensors,
  onDragEnd,

  onDeleteOption,
  onUpdateOption,

  optionDraft,
}: Props) {
  const style: CSSProperties | undefined = undefined;

  return (
    <Card id={`option-set-${set.id}`} style={style} className={`${feedStyles.card.base} ${!set.is_active ? feedStyles.card.inactive : ''}`}>
      <CardHeader className={feedStyles.layout.cardHeader} onClick={onToggleExpand}>
        <div className={feedStyles.layout.cardHeaderInner}>
          <div className={feedStyles.layout.cardHeaderLeft}>
            {expanded ? (
              <ChevronDown className={feedStyles.icon.chevron} />
            ) : (
              <ChevronRight className={feedStyles.icon.chevron} />
            )}

            <Checkbox
              checked={set.is_active}
              onCheckedChange={() => onToggleSetActive()}
              onClick={(e) => e.stopPropagation()}
              className="w-5 h-5 border-[#E8E5E0] data-[state=checked]:bg-[#6366F1] data-[state=checked]:border-[#6366F1]"
            />

            {nameEdit.editing ? (
              <input
                value={nameEdit.value}
                onChange={(e) => nameEdit.onChange(e.target.value)}
                onKeyDown={(e) => {
                  if (e.key === 'Enter') {
                    e.preventDefault();
                    e.currentTarget.blur(); // blur 트리거해서 저장
                  }
                  if (e.key === 'Escape') {
                    nameEdit.onCancel();
                  }
                }}
                onBlur={() => {
                  const trimmed = nameEdit.value.trim();
                  if (!trimmed) {
                    nameEdit.onCancel();
                  } else {
                    nameEdit.onConfirm();
                  }
                }}
                onClick={(e) => e.stopPropagation()}
                autoFocus
                className={feedStyles.input.setName}
                placeholder="평가항목명"
              />
            ) : (
              <>
                <span className={!set.is_active ? feedStyles.text.sectionTitleInactive : feedStyles.text.sectionTitle}>
                  {set.name}
                </span>
                {/* ✅ 연필 아이콘 밖으로 - 이름 옆에 바로 표시 */}
                <Button
                  type="button"
                  variant="ghost"
                  size="icon"
                  className="h-6 w-6 ml-1"
                  onClick={(e) => {
                    e.stopPropagation();
                    nameEdit.onStart();
                  }}
                >
                  <Pencil className="h-3 w-3 text-gray-400 hover:text-gray-600" />
                </Button>
              </>
            )}

            <span className={feedStyles.badge.gray}>
              {set.is_scored ? (set.score_step ? `${set.score_step}점 단위` : '점수형') : '문장형'}
            </span>
          </div>

          <div className={feedStyles.layout.cardHeaderRight}>
            <DropdownMenu>
              <DropdownMenuTrigger asChild>
                <Button
                  type="button"
                  variant="ghost"
                  size="icon"
                  className={feedStyles.button.ghost}
                  onClick={(e) => e.stopPropagation()}
                  aria-label="더보기"
                >
                  <MoreVertical className={feedStyles.icon.small} />
                </Button>
              </DropdownMenuTrigger>

              <DropdownMenuContent align="end" onClick={(e) => e.stopPropagation()} className="w-40">
                <DropdownMenuItem
                  onSelect={() => {
                    nameEdit.onStart();
                  }}
                >
                  <Pencil className="mr-2 h-4 w-4" />
                  이름 변경
                </DropdownMenuItem>

                <DropdownMenuItem
                  onSelect={async () => {
                    const ok = await confirm({
                      title: '평가항목 복제',
                      description: `이 평가항목을 복제할까요?\n\n복제본은 "${set.name} (복제)" 형태로 만들어집니다.`,
                      confirmLabel: '복제',
                    });
                    if (!ok) return;
                    onDuplicate();
                  }}
                >
                  <Copy className="mr-2 h-4 w-4" />
                  복제
                </DropdownMenuItem>

                <DropdownMenuSeparator />

                <DropdownMenuItem className="text-red-600 focus:text-red-600" onSelect={onDeleteSet}>
                  <Trash2 className="mr-2 h-4 w-4" />
                  삭제
                </DropdownMenuItem>
              </DropdownMenuContent>
            </DropdownMenu>
          </div>
        </div>
      </CardHeader>

      {expanded && (
        <CardContent className={feedStyles.card.expandedContent}>
          {/* 카테고리 선택 (set-level) */}
          <div
            className={cn(
              feedStyles.layout.categoryRow,
              isEditMode ? feedStyles.layout.categoryRowBoxOn : feedStyles.layout.categoryRowBoxOff
            )}
          >
            {!isEditMode && (
              <div className={feedStyles.text.categoryHint}>
                <Info className={cn(feedStyles.icon.info, 'w-3 h-3')} />
                카테고리 편집 모드를 켜면 수정할 수 있습니다
              </div>
            )}

            <div className="flex flex-col gap-2">
              <div className="flex items-center gap-2">
                <span className="font-semibold">카테고리:</span>

                {REPORT_CATEGORIES.map((cat) => {
                  const isActive = categoryValue === cat;
                  const disabled = !isEditMode;

                  return (
                    <button
                      key={cat}
                      type="button"
                      title={disabled ? '편집하려면 상단에서 카테고리 편집 모드를 켜세요' : REPORT_CATEGORY_DESCRIPTION[cat]}
                      className={
                        feedStyles.categoryButton.base +
                        ' ' +
                        (isActive ? feedStyles.categoryButton.active : feedStyles.categoryButton.inactive) +
                        ' ' +
                        (disabled ? feedStyles.categoryButton.disabled : feedStyles.categoryButton.interactiveHover)
                      }
                      onClick={async (e) => {
                        e.stopPropagation();
                        if (disabled) return;

                        const ok = await confirm({
                          title: '카테고리 변경',
                          description: '⚠️ 이 설정을 변경하면 이 세트의 모든 옵션 카테고리도 동일하게 일괄 변경됩니다.\n\n정말 변경하시겠습니까?',
                          confirmLabel: '변경',
                        });
                        if (!ok) return;

                        onChangeCategory(cat);
                      }}
                    >
                      {REPORT_CATEGORY_LABEL[cat]}
                    </button>
                  );
                })}
              </div>
              
              {/* 선택된 카테고리 설명 표시 */}
              {categoryValue && (
                <p className="text-xs text-gray-500 ml-[70px]">
                  {REPORT_CATEGORY_DESCRIPTION[categoryValue]}
                </p>
              )}
            </div>
          </div>

          {/* 주간 리포트 설정 */}
          <div className="mt-4 p-4 bg-indigo-50/50 rounded-lg border border-indigo-100">
            <div className="flex items-center gap-3">
              <Checkbox
                id={`weekly-stats-${set.id}`}
                checked={set.is_in_weekly_stats ?? true}
                onCheckedChange={() => onToggleWeeklyStats()}
                className="w-4 h-4 border-gray-300 data-[state=checked]:bg-indigo-600 data-[state=checked]:border-indigo-600"
              />
              <label 
                htmlFor={`weekly-stats-${set.id}`}
                className="text-sm text-gray-700 cursor-pointer"
              >
                📊 주간 리포트에 포함
              </label>
            </div>
          </div>

          {/* Options list (DnD) */}
          <DndContext sensors={sensors} collisionDetection={closestCenter} onDragEnd={onDragEnd}>
            <SortableContext items={optionList.map((o) => o.id)} strategy={verticalListSortingStrategy}>
              <div className={feedStyles.layout.optionList}>
                {optionList.map((option) => (
                  <SortableOptionRow
                    key={option.id}
                    option={option}
                    isScored={set.is_scored}
                    onDelete={(optionId) => onDeleteOption(optionId)}
                    onUpdate={(optionId, newLabel, newScore) => onUpdateOption(optionId, newLabel, newScore)}
                  />
                ))}

                {optionList.length === 0 && (
                  <p className="text-sm text-gray-400 py-4 text-center">
                    아래에서 옵션을 추가해주세요 💡
                  </p>
                )}
              </div>
            </SortableContext>
          </DndContext>

          {/* Add option */}
          <div className={cn(
            feedStyles.layout.optionAddRow,
            isHighlightAdd && optionList.length === 0 && 'p-3 -mx-1 rounded-lg bg-[#EEF2FF] border border-[#6366F1]/30'
          )}>
            <input
              className={cn(
                feedStyles.input.base,
                isHighlightAdd && optionList.length === 0 && 'border-[#6366F1] bg-white ring-2 ring-[#6366F1]/20'
              )}
              placeholder={set.is_scored ? '옵션명 + 점수 (예: 우수 100) / 점수 생략시 점수 제외' : '옵션명 (예: 등원)'}
              value={optionDraft.value}
              onChange={(e) => optionDraft.onChange(e.target.value)}
              onKeyDown={(e) => {
                if (e.key === 'Enter') optionDraft.onAdd();
              }}
              autoFocus={isHighlightAdd && optionList.length === 0}
            />

            <Button 
              onClick={optionDraft.onAdd}
              className="bg-[#6366F1] hover:bg-[#4F46E5] text-white"
            >
              추가
            </Button>
          </div>
        </CardContent>
      )}
    </Card>
  );
}
