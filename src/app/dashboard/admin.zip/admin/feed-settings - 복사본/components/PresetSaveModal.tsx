'use client';

import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Info } from 'lucide-react';
import { feedStyles } from '@/styles/feedSettings.styles';

type Props = {
  open: boolean;
  presetName: string;
  isSaving: boolean;

  onChangeName: (value: string) => void;
  onConfirm: () => void;
  onClose: () => void;
};

export default function PresetSaveModal({
  open,
  presetName,
  isSaving,
  onChangeName,
  onConfirm,
  onClose,
}: Props) {
  if (!open) return null;

  return (
    <div
      className="fixed inset-0 z-50 flex items-center justify-center bg-black/30 p-4"
      onMouseDown={onClose}
    >
      <div className="w-full max-w-3xl" onMouseDown={(e) => e.stopPropagation()}>
        <Card className={`${feedStyles.card.modal} ${feedStyles.card.modalGray}`}>
          <CardHeader>
            <CardTitle className={feedStyles.layout.modalTitleRow}>
              <Info className={feedStyles.icon.infoGray} />
              기본형 저장
            </CardTitle>
            <p className={feedStyles.text.modalDescription}>
              현재 설정된 평가항목 구성을 저장합니다. 이름을 입력해주세요.
            </p>
          </CardHeader>

          <CardContent>
            <input
              className={feedStyles.input.base}
              placeholder="프리셋 이름 (예: 중등 내신 기간용)"
              value={presetName}
              onChange={(e) => onChangeName(e.target.value)}
              onKeyDown={(e) => {
                if (e.key === 'Enter') onConfirm();
              }}
              autoFocus
            />

            <div className={feedStyles.layout.modalActionRow}>
              <Button
                type="button"
                className={feedStyles.button.primary}
                disabled={!presetName.trim() || isSaving}
                onClick={onConfirm}
              >
                {isSaving ? '저장 중…' : '저장'}
              </Button>

              <Button type="button" variant="ghost" onClick={onClose}>
                취소
              </Button>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
