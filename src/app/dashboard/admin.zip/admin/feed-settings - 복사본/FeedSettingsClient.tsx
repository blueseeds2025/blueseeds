'use client';

import { useCallback, useEffect, useMemo, useState } from 'react';
import {
  Plus,
  Wrench,
  Info,
  Save,
  BookOpen,
  Languages,
  Calculator,
  FolderOpen,
  Trash2,
} from 'lucide-react';

import { PointerSensor, useSensor, useSensors } from '@dnd-kit/core';

import { createBrowserClient } from '@supabase/ssr';
import type { Database } from '@/lib/database.types';

import type { ReportCategory } from '@/types/feed-settings';
import { DRAG_ACTIVATION_DISTANCE } from './feedSettings.constants';

import { Switch } from '@/components/ui/switch';
import { Button } from '@/components/ui/button';
import { Card, CardContent } from '@/components/ui/card';

import { toast } from 'sonner';

import { feedStyles } from '@/styles/feedSettings.styles';

// Hooks
import { useFeedData } from './hooks/useFeedData';
import { usePresetUI } from './hooks/usePresetUI';
import { usePresetList } from './hooks/usePresetList';

// Components
import OptionSetCard from './components/OptionSetCard';
import PresetListModal from './components/PresetListModal';
import PresetSaveModal from './components/PresetSaveModal';
import TemplateSelectModal from './components/TemplateSelectModal';
import AddItemForm from './components/AddItemForm';
import { ScoringWizardModal } from './components/WizardModals';

const presetStorageKey = (tenantId: string) => `feed_last_preset_name:${tenantId}`;

// =======================
// Empty State - 템플릿 선택 화면
// =======================
type EmptyStateProps = {
  onSelectTemplate: (key: 'custom' | 'basic' | 'english' | 'text') => void;
};

function EmptyState({ onSelectTemplate }: EmptyStateProps) {
  return (
    <div className="flex flex-col items-center justify-center min-h-[60vh] px-4">
      <h1 className="text-2xl font-bold text-gray-900 mb-2">피드 설정</h1>
      <p className="text-gray-500 mb-8">평가 템플릿을 선택해주세요</p>

      <div className="grid grid-cols-2 gap-4 w-full max-w-md">
        <Card
          className="cursor-pointer hover:shadow-md transition-shadow border-2 hover:border-blue-300"
          onClick={() => onSelectTemplate('custom')}
        >
          <CardContent className="flex flex-col items-center justify-center py-6">
            <Wrench className="w-8 h-8 text-blue-500 mb-2" />
            <div className="font-semibold text-gray-900">직접 만들기</div>
            <div className="text-sm text-gray-500">빈 화면</div>
          </CardContent>
        </Card>

        <Card
          className="cursor-pointer hover:shadow-md transition-shadow border-2 hover:border-green-300"
          onClick={() => onSelectTemplate('basic')}
        >
          <CardContent className="flex flex-col items-center justify-center py-6">
            <BookOpen className="w-8 h-8 text-green-500 mb-2" />
            <div className="font-semibold text-gray-900">기본형</div>
            <div className="text-sm text-gray-500">종합학원용</div>
          </CardContent>
        </Card>

        <Card
          className="cursor-pointer hover:shadow-md transition-shadow border-2 hover:border-purple-300"
          onClick={() => onSelectTemplate('english')}
        >
          <CardContent className="flex flex-col items-center justify-center py-6">
            <Languages className="w-8 h-8 text-purple-500 mb-2" />
            <div className="font-semibold text-gray-900">영어형</div>
            <div className="text-sm text-gray-500">어학원용</div>
          </CardContent>
        </Card>

        <Card
          className="cursor-pointer hover:shadow-md transition-shadow border-2 hover:border-orange-300"
          onClick={() => onSelectTemplate('text')}
        >
          <CardContent className="flex flex-col items-center justify-center py-6">
            <Calculator className="w-8 h-8 text-orange-500 mb-2" />
            <div className="font-semibold text-gray-900">문장형</div>
            <div className="text-sm text-gray-500">점수 없음</div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}

// =======================
// Page
// =======================
export default function FeedSettingsClient() {
  // Supabase client
  const supabase = useMemo(
    () =>
      createBrowserClient<Database>(
        process.env.NEXT_PUBLIC_SUPABASE_URL!,
        process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY!
      ),
    []
  );

  // DnD sensors
  const sensors = useSensors(
    useSensor(PointerSensor, { activationConstraint: { distance: DRAG_ACTIVATION_DISTANCE } })
  );

  // =======================
  // Helpers
  // =======================
  const toastLoadFail = () => toast.error('불러오기에 실패했습니다. 잠시 후 다시 시도해주세요.', { duration: 4000 });
  const toastSaveFail = () => toast.error('저장에 실패했습니다. 잠시 후 다시 시도해주세요.', { duration: 4000 });

  // =======================
  // Tenant ID 캐싱
  // =======================
  const [cachedTenantId, setCachedTenantId] = useState<string | null>(null);

  const getTenantId = useCallback(async (): Promise<string | null> => {
    // 이미 캐싱되어 있으면 바로 반환
    if (cachedTenantId) return cachedTenantId;

    const { data: { user } } = await supabase.auth.getUser();
    if (!user) return null;

    const { data: profile, error } = await supabase
      .from('profiles')
      .select('tenant_id')
      .eq('id', user.id)
      .single();

    if (error || !profile?.tenant_id) return null;
    
    // 캐싱
    setCachedTenantId(profile.tenant_id);
    return profile.tenant_id;
  }, [supabase, cachedTenantId]);

  // =======================
  // UI State
  // =======================
  const [expandedSets, setExpandedSets] = useState<Set<string>>(new Set());
  const [isEditMode, setIsEditMode] = useState(false);
  const [optionDraft, setOptionDraft] = useState<Record<string, string>>({});
  const [editingSetId, setEditingSetId] = useState<string | null>(null);
  const [editingSetName, setEditingSetName] = useState('');

  // Add item form state
  const [isAddingItem, setIsAddingItem] = useState(false);
  const [newItemName, setNewItemName] = useState('');
  const [newItemCategory, setNewItemCategory] = useState<ReportCategory | null>(null);

  // Template select modal state
  const [showTemplateModal, setShowTemplateModal] = useState(false);
  const [pendingItemName, setPendingItemName] = useState('');

  // =======================
  // Data Hook
  // =======================
  const {
    activeConfig,
    optionSets,
    options,
    categoryDraft,
    currentTemplate,
    setCurrentTemplate,
    showWizard,
    setShowWizard,
    wizardStep,
    setWizardStep,
    isLoading,
    loadOptionSets,
    handleOptionDragEnd,
    updateOption,
    deleteOption,
    addOptionFromInput,
    toggleSetActive,
    deleteSet,
    updateSetName,
    changeSetCategory,
    duplicateSet,
    applyTemplate,
    setCustomTemplate,
    addItemWithTemplate,
    archiveAllCurrentSets,
  } = useFeedData({
    supabase,
    getTenantId,
    setExpandedSets,
    toastLoadFail,
    toastSaveFail,
  });

  // =======================
  // Preset Hooks
  // =======================
  const {
    showPresetModal,
    setShowPresetModal,
    presetName,
    setPresetName,
    openPresetModal,
    confirmSavePreset,
    isSaving,
  } = usePresetUI(optionSets, options);

  const {
    showPresetListModal,
    setShowPresetListModal,
    presetList,
    applyingPresetId,
    deletingPresetId,
    lastAppliedPresetName,
    openPresetList,
    handleApplyPreset,
    handleDeletePreset,
    clearLastAppliedPreset,
  } = usePresetList({
    getTenantId,
    loadOptionSets,
    presetStorageKey,
    beforeApply: () => {
      setShowWizard(false);
      setShowTemplateModal(false);
      setIsAddingItem(false);
      setShowPresetModal(false);
      setPresetName('');
    },
  });

  // =======================
  // Effects
  // =======================
  useEffect(() => {
    setShowPresetModal(false);
    setShowTemplateModal(false);
    setIsAddingItem(false);
    setPresetName('');
    setPendingItemName('');
    setNewItemName('');
    setNewItemCategory(null);
  }, [setShowPresetModal, setPresetName]);

  useEffect(() => {
    if (!showPresetModal) return;

    const onKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Escape') {
        setShowPresetModal(false);
        setPresetName('');
      }
    };

    window.addEventListener('keydown', onKeyDown);
    return () => window.removeEventListener('keydown', onKeyDown);
  }, [showPresetModal, setShowPresetModal, setPresetName]);

  // =======================
  // Handlers
  // =======================
  const handleUpdateSetName = useCallback(
    async (setId: string) => {
      const success = await updateSetName(setId, editingSetName);
      if (success) {
        setEditingSetId(null);
        setEditingSetName('');
      }
    },
    [editingSetName, updateSetName]
  );

  const handleChangeSetCategory = useCallback(
    async (set: typeof optionSets[0], newCategory: ReportCategory) => {
      const success = await changeSetCategory(set, newCategory);
      if (success) {
        setIsEditMode(false);
      }
    },
    [changeSetCategory]
  );

  const handleDuplicateSet = useCallback(
    async (set: typeof optionSets[0]) => {
      const newSet = await duplicateSet(set);
      if (newSet) {
        setEditingSetId(newSet.id);
        setEditingSetName(`${set.name} (복제)`);
      }
    },
    [duplicateSet]
  );

  const addNewItem = useCallback(async () => {
    if (!newItemName.trim()) {
      toast.error('평가항목명을 입력하세요');
      return;
    }
    if (!newItemCategory) {
      toast.error('AI 리포트 영역을 먼저 선택해주세요');
      return;
    }
    if (!currentTemplate) {
      setPendingItemName(newItemName);
      setShowTemplateModal(true);
      return;
    }

    const created = await addItemWithTemplate(currentTemplate, newItemName, newItemCategory);
    if (created) {
      setNewItemName('');
      setNewItemCategory(null);
      setIsAddingItem(false);
    }
  }, [addItemWithTemplate, currentTemplate, newItemCategory, newItemName]);

  const handleTemplateSelect = useCallback(
    async (template: 'precise' | 'general' | 'text') => {
      const name = pendingItemName || newItemName;
      const category = newItemCategory;

      if (!name.trim()) {
        toast.error('평가항목명을 입력하세요');
        setShowTemplateModal(false);
        return;
      }
      if (!category) {
        toast.error('AI 리포트 영역을 먼저 선택해주세요');
        setShowTemplateModal(false);
        return;
      }

      const created = await addItemWithTemplate(template, name, category);
      if (created) {
        setPendingItemName('');
        setNewItemName('');
        setNewItemCategory(null);
        setIsAddingItem(false);
        setShowTemplateModal(false);
      }
    },
    [addItemWithTemplate, newItemCategory, newItemName, pendingItemName]
  );

  const toggleExpand = useCallback((setId: string) => {
    setShowPresetListModal(false);
    setExpandedSets((prev) => {
      const next = new Set(prev);
      if (next.has(setId)) next.delete(setId);
      else next.add(setId);
      return next;
    });
  }, [setShowPresetListModal]);

  const handleResetSettings = useCallback(async () => {
    // archiveAllCurrentSets 내부에서 confirm 처리함
    const archived = await archiveAllCurrentSets();
    if (!archived) return;

    // ✅ localStorage에서 마지막 적용 프리셋명 제거
    await clearLastAppliedPreset();

    setShowWizard(false); // EmptyState 보이게
    setIsAddingItem(false);
    setCurrentTemplate(null);
    setNewItemName('');
    setPendingItemName('');
    setNewItemCategory(null);
  }, [archiveAllCurrentSets, clearLastAppliedPreset, setCurrentTemplate, setShowWizard]);

  const handleCancelAddItem = useCallback(() => {
    setIsAddingItem(false);
    setNewItemName('');
    setNewItemCategory(null);
  }, []);

  // =======================
  // Empty State Handler
  // =======================
  const handleEmptyTemplateSelect = useCallback(
    (key: 'custom' | 'basic' | 'english' | 'text') => {
      if (key === 'custom') {
        // 직접 만들기 → scoring 선택으로
        setShowWizard(true);
        setWizardStep('scoring');
      } else {
        // 템플릿 적용
        void applyTemplate(key);
      }
    },
    [applyTemplate, setShowWizard, setWizardStep]
  );

  // =======================
  // Render
  // =======================

  // 로딩 중일 때
  if (isLoading) {
    return (
      <div className="flex items-center justify-center min-h-[60vh]">
        <div className="text-gray-500">불러오는 중...</div>
      </div>
    );
  }

  // 데이터가 없으면 템플릿 선택 화면만 표시
  if (optionSets.length === 0 && !showWizard) {
    return (
      <>
        <EmptyState onSelectTemplate={handleEmptyTemplateSelect} />
        
        {/* Scoring 선택 모달 (직접 만들기 선택시) */}
        <ScoringWizardModal
          open={showWizard && wizardStep === 'scoring'}
          onBack={() => setShowWizard(false)}
          onSelectScoring={(key) => void setCustomTemplate(key)}
        />
      </>
    );
  }

  // 데이터가 있거나 위저드 진행중이면 기존 UI
  return (
    <div className={feedStyles.layout.page}>
      {/* Header */}
      <div className="flex items-center justify-between mb-4">
        {/* 좌측: 제목 + 모드 배지 + AI 스위치 */}
        <div className="flex items-center gap-3">
          <h1 className={feedStyles.text.pageTitle}>피드 설정</h1>
          {currentTemplate && (
            <span className="px-2 py-1 text-xs font-medium text-gray-600 bg-gray-100 rounded">
              {currentTemplate === 'text'
                ? '문장형'
                : currentTemplate === 'precise'
                ? '5점 단위'
                : '10점 단위'}
            </span>
          )}
          <div className="flex items-center gap-2 text-sm text-gray-600 ml-2">
            <span>AI 매핑</span>
            <Switch checked={isEditMode} onCheckedChange={(v) => setIsEditMode(Boolean(v))} />
          </div>
        </div>

        {/* 우측: 설정 관리 버튼들 */}
        <div className="flex items-center gap-2">
          <Button
            variant="outline"
            size="sm"
            onClick={() => void openPresetModal()}
          >
            <Save className="w-4 h-4 mr-1" />
            내 설정 저장
          </Button>
          <Button
            variant="outline"
            size="sm"
            onClick={() => void openPresetList()}
          >
            <FolderOpen className="w-4 h-4 mr-1" />
            저장된 설정
          </Button>
          <Button
            variant="outline"
            size="sm"
            onClick={handleResetSettings}
            className="text-red-600 hover:text-red-700 hover:bg-red-50"
          >
            <Trash2 className="w-4 h-4 mr-1" />
            전체 삭제
          </Button>
        </div>
      </div>

      {isEditMode && (
        <div className={feedStyles.layout.editModeHint}>
          <Info className={feedStyles.icon.small} />
          각 평가항목의 AI 리포트 영역(학습/태도/출결/없음)을 변경할 수 있습니다.
        </div>
      )}

      {/* 평가항목 추가 버튼 */}
      <div className="mb-4">
        <Button
          onClick={() => {
            setIsAddingItem(true);
            setShowWizard(false);
          }}
          variant="default"
          className={feedStyles.button.primaryLarge}
        >
          <Plus className={feedStyles.icon.buttonIcon} />
          평가항목 추가
        </Button>
      </div>

      {/* Last applied preset */}
      {lastAppliedPresetName && (
        <div className={feedStyles.layout.presetLabel}>
          현재 적용된 기본형: <span className={feedStyles.text.definitionLabel}>{lastAppliedPresetName}</span>
        </div>
      )}

      {/* Modals */}
      <TemplateSelectModal
        open={showTemplateModal}
        pendingItemName={pendingItemName}
        onSelectPrecise={() => void handleTemplateSelect('precise')}
        onSelectGeneral={() => void handleTemplateSelect('general')}
        onSelectText={() => void handleTemplateSelect('text')}
        onClose={() => {
          setShowTemplateModal(false);
          setPendingItemName('');
        }}
      />

      <PresetSaveModal
        open={showPresetModal}
        presetName={presetName}
        isSaving={isSaving}
        onChangeName={(v) => setPresetName(v)}
        onConfirm={() => void confirmSavePreset()}
        onClose={() => {
          setShowPresetModal(false);
          setPresetName('');
        }}
      />

      <PresetListModal
        open={showPresetListModal}
        onClose={() => setShowPresetListModal(false)}
        presets={presetList}
        applyingPresetId={applyingPresetId}
        deletingPresetId={deletingPresetId}
        onApply={(id, name) => void handleApplyPreset(id, name)}
        onDelete={(id, name) => void handleDeletePreset(id, name)}
      />

      {/* Scoring 선택 모달 */}
      <ScoringWizardModal
        open={showWizard && wizardStep === 'scoring'}
        onBack={() => setShowWizard(false)}
        onSelectScoring={(key) => void setCustomTemplate(key)}
      />

      {/* Add item form */}
      {isAddingItem && (
        <AddItemForm
          currentTemplate={currentTemplate}
          newItemName={newItemName}
          newItemCategory={newItemCategory}
          onChangeName={setNewItemName}
          onChangeCategory={setNewItemCategory}
          onSubmit={() => void addNewItem()}
          onCancel={handleCancelAddItem}
        />
      )}

      {/* Option Sets */}
      {optionSets.map((set) => (
        <OptionSetCard
          key={set.id}
          set={set}
          expanded={expandedSets.has(set.id)}
          isEditMode={isEditMode}
          categoryValue={
            (categoryDraft[set.id] ?? set.default_report_category ?? 'study') as ReportCategory
          }
          optionList={options[set.id] ?? []}
          onToggleExpand={() => toggleExpand(set.id)}
          onToggleSetActive={() => void toggleSetActive(set)}
          nameEdit={{
            editing: editingSetId === set.id,
            value: editingSetName,
            onStart: () => {
              setEditingSetId(set.id);
              setEditingSetName(set.name);
            },
            onChange: (v) => setEditingSetName(v),
            onConfirm: () => void handleUpdateSetName(set.id),
            onCancel: () => {
              setEditingSetId(null);
              setEditingSetName('');
            },
          }}
          onDuplicate={() => void handleDuplicateSet(set)}
          onDeleteSet={() => void deleteSet(set.id)}
          onChangeCategory={(cat) => void handleChangeSetCategory(set, cat)}
          sensors={sensors}
          onDragEnd={(event) => void handleOptionDragEnd(set.id, event)}
          onDeleteOption={(optionId) => void deleteOption(optionId)}
          onUpdateOption={(optionId, newLabel, newScore) =>
            void updateOption(optionId, newLabel, newScore)
          }
          optionDraft={{
            value: optionDraft[set.id] ?? '',
            onChange: (v) =>
              setOptionDraft((prev) => ({
                ...prev,
                [set.id]: v,
              })),
            onAdd: () => {
              const draft = (optionDraft[set.id] ?? '').trim();
              if (!draft) return;

              // ✅ 입력창 먼저 비우고, 서버 요청은 비동기로
              setOptionDraft((prev) => ({ ...prev, [set.id]: '' }));
              void addOptionFromInput(set.id, draft);
            },
          }}
        />
      ))}
    </div>
  );
}