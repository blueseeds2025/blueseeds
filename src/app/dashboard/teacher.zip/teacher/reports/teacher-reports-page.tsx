import { redirect } from 'next/navigation';
import { createClient } from '@/lib/supabase/server';
import { TeacherReportClient } from './TeacherReportClient';

export default async function TeacherReportsPage() {
  const supabase = await createClient();
  
  // 1. 인증 확인
  const { data: { user } } = await supabase.auth.getUser();
  if (!user) {
    redirect('/login');
  }
  
  // 2. 프로필 확인
  const { data: profile } = await supabase
    .from('profiles')
    .select('tenant_id, role')
    .eq('id', user.id)
    .single();
  
  if (!profile) {
    redirect('/login');
  }
  
  // 3. 권한 확인 (teacher만)
  if (profile.role !== 'teacher') {
    // owner는 admin 리포트로
    if (profile.role === 'owner') {
      redirect('/dashboard/admin/reports');
    }
    redirect('/dashboard');
  }
  
  // 4. 리포트 조회 권한 확인
  const { data: permissions } = await supabase
    .from('teacher_permissions')
    .select('can_view_reports')
    .eq('teacher_id', user.id)
    .eq('tenant_id', profile.tenant_id)
    .is('deleted_at', null)
    .maybeSingle();
  
  // 권한 없으면 (기본값은 true이므로 명시적 false만 차단)
  if (permissions?.can_view_reports === false) {
    return (
      <div className="p-6 max-w-6xl mx-auto">
        <div className="bg-amber-50 border border-amber-200 rounded-xl p-8 text-center">
          <div className="text-4xl mb-4">🔒</div>
          <h2 className="text-lg font-semibold text-amber-800 mb-2">
            리포트 조회 권한이 없습니다
          </h2>
          <p className="text-amber-700">
            원장선생님께 리포트 조회 권한을 요청해주세요.
          </p>
        </div>
      </div>
    );
  }
  
  return (
    <div className="p-6 max-w-6xl mx-auto">
      <TeacherReportClient />
    </div>
  );
}
