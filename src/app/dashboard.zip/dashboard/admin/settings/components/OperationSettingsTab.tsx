// ============================================================================
// 운영 설정 탭 컴포넌트
// ============================================================================
'use client';

import Link from 'next/link';
import type { SettingsData } from '@/types/settings.types';

interface Props {
  settings: SettingsData;
  onUpdate: () => void;
}

export default function OperationSettingsTab({ settings, onUpdate }: Props) {
  const { stats } = settings;
  
  return (
    <div className="space-y-6">
      {/* 피드 항목 관리 */}
      <section className="bg-white rounded-xl border border-stone-200 p-6">
        <div className="flex items-center justify-between mb-4">
          <div>
            <h2 className="text-lg font-semibold text-stone-800">📝 피드 항목 관리</h2>
            <p className="text-sm text-stone-500 mt-1">
              학생 피드에 사용할 평가 항목을 설정합니다
            </p>
          </div>
          <div className="text-right">
            <p className="text-2xl font-bold text-stone-800">{stats.feedSetCount}</p>
            <p className="text-xs text-stone-500">활성 항목</p>
          </div>
        </div>
        
        {stats.unmappedCategoryCount > 0 && (
          <div className="mb-4 p-3 bg-amber-50 border border-amber-200 rounded-lg">
            <p className="text-sm text-amber-800">
              ⚠️ {stats.unmappedCategoryCount}개 항목의 통계 카테고리가 미지정입니다
            </p>
          </div>
        )}
        
        <Link
          href="/dashboard/admin/feed-settings"
          className="block w-full p-4 border border-stone-200 rounded-lg text-center hover:border-[#6366F1]/30 hover:bg-[#6366F1]/5 transition-colors"
        >
          <p className="font-medium text-[#6366F1]">피드 항목 설정으로 이동 →</p>
        </Link>
      </section>
      
      {/* 선생님 권한 관리 */}
      <section className="bg-white rounded-xl border border-stone-200 p-6">
        <div className="flex items-center justify-between mb-4">
          <div>
            <h2 className="text-lg font-semibold text-stone-800">👩‍🏫 선생님 권한</h2>
            <p className="text-sm text-stone-500 mt-1">
              선생님별 기능 접근 권한을 설정합니다
            </p>
          </div>
          <div className="text-right">
            <p className="text-2xl font-bold text-stone-800">{stats.teacherCount}</p>
            <p className="text-xs text-stone-500">등록된 선생님</p>
          </div>
        </div>
        
        <Link
          href="/dashboard/admin/teacher-permissions"
          className="block w-full p-4 border border-stone-200 rounded-lg text-center hover:border-[#6366F1]/30 hover:bg-[#6366F1]/5 transition-colors"
        >
          <p className="font-medium text-[#6366F1]">선생님 권한 설정으로 이동 →</p>
        </Link>
      </section>
      
      {/* 담당반 배정 */}
      <section className="bg-white rounded-xl border border-stone-200 p-6">
        <div className="flex items-center justify-between mb-4">
          <div>
            <h2 className="text-lg font-semibold text-stone-800">🏠 담당반 배정</h2>
            <p className="text-sm text-stone-500 mt-1">
              선생님별 담당 반을 배정합니다
            </p>
          </div>
        </div>
        
        <Link
          href="/dashboard/admin/classes"
          className="block w-full p-4 border border-stone-200 rounded-lg text-center hover:border-[#6366F1]/30 hover:bg-[#6366F1]/5 transition-colors"
        >
          <p className="font-medium text-[#6366F1]">반 관리로 이동 →</p>
        </Link>
      </section>
    </div>
  );
}
