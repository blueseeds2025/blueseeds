'use client';

import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Info, Trash2 } from 'lucide-react';
import { feedStyles } from '@/styles/feedSettings.styles';

type PresetSummary = {
  id: string;
  name: string;
  created_at: string;
  updated_at: string;
  setCount: number;
  optionCount: number;
};

type Props = {
  open: boolean;
  onClose: () => void;

  presets: PresetSummary[];

  applyingPresetId: string | null;
  deletingPresetId: string | null;

  onApply: (presetId: string, presetName: string) => void;
  onDelete: (presetId: string, presetName: string) => void;
};

export default function PresetListModal({
  open,
  onClose,
  presets,
  applyingPresetId,
  deletingPresetId,
  onApply,
  onDelete,
}: Props) {
  if (!open) return null;

  const isApplying = applyingPresetId !== null;
  const isDeleting = deletingPresetId !== null;

  return (
    <div
      onMouseDown={onClose}
      className="fixed inset-0 z-50 flex items-center justify-center bg-black/30 p-4"
    >
      <Card
        onMouseDown={(e) => e.stopPropagation()}
        className={`${feedStyles.card.modal} ${feedStyles.card.modalGray} w-full max-w-xl`}
      >
        <CardHeader>
          <CardTitle className={feedStyles.layout.modalTitleRow}>
            <Info className={feedStyles.icon.infoGray} />
            기본형 불러오기
          </CardTitle>
          <p className={feedStyles.text.modalDescription}>
            저장된 프리셋 목록입니다. 적용할 구성을 선택하세요.
          </p>
        </CardHeader>

        <CardContent>
          {presets.length === 0 ? (
            <p className={feedStyles.text.emptyState}>저장된 프리셋이 없습니다.</p>
          ) : (
            <div className="space-y-2">
              {presets.map((p) => (
                <div
                  key={p.id}
                  className="flex items-center justify-between rounded-lg border bg-white px-3 py-2"
                >
                  <div className="min-w-0">
                    <div className="font-semibold truncate">{p.name}</div>
                    <div className="text-xs text-gray-500">
                      세트 {p.setCount}개 · 옵션 {p.optionCount}개
                    </div>
                  </div>

                  <div className="flex items-center gap-2">
                    <Button
                      type="button"
                      variant="ghost"
                      className={feedStyles.button.danger}
                      disabled={isDeleting || isApplying}
                      onClick={() => onDelete(p.id, p.name)}
                      title="삭제"
                    >
                      <Trash2 className={feedStyles.icon.small} />
                    </Button>

                    <Button
                      type="button"
                      className={feedStyles.button.primary}
                      disabled={isApplying || isDeleting}
                      onClick={() => onApply(p.id, p.name)}
                    >
                      {isApplying && applyingPresetId === p.id ? '적용 중…' : '적용'}
                    </Button>
                  </div>
                </div>
              ))}
            </div>
          )}

          <div className="mt-4 flex justify-end">
            <Button type="button" variant="ghost" onClick={onClose}>
              닫기
            </Button>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
